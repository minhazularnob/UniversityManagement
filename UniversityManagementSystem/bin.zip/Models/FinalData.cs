﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace UniversityManagementSystem.Models
{
    public class FinalData
    {
        public string CourseCode { get; set; }
        public string CourseName { get; set; }
        public string Info { get; set; }
    }
}